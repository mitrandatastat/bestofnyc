
### Read in the data


```python
import pandas
import numpy
import re
import random 
import matplotlib.pyplot as plt
import matplotlib.colors as colors
from mpl_toolkits.basemap import Basemap
%matplotlib inline 

data_files = [
    "ap_2010.csv",
    "class_size.csv",
    "demographics.csv",
    "graduation.csv",
    "hs_directory.csv",
    "sat_results.csv"
]

data = {}

for f in data_files:
    d = pandas.read_csv("databank/{0}".format(f))
    data[f.replace(".csv", "")] = d
```

### Read in the surveys


```python
all_survey = pandas.read_csv("databank/survey_all.txt", delimiter="\t", encoding='windows-1252')
d75_survey = pandas.read_csv("databank/survey_d75.txt", delimiter="\t", encoding='windows-1252')

# Combine two data frames by rows
survey = pandas.concat([all_survey, d75_survey], axis=0)

# Change the column head to align with other data frame
survey["DBN"] = survey["dbn"]

# Identify and make a feature list of our interest
survey_fields = [
    "DBN", 
    "rr_s", 
    "rr_t", 
    "rr_p", 
    "N_s", 
    "N_t", 
    "N_p", 
    "saf_p_11", 
    "com_p_11", 
    "eng_p_11", 
    "aca_p_11", 
    "saf_t_11", 
    "com_t_11", 
    "eng_t_10", 
    "aca_t_11", 
    "saf_s_11", 
    "com_s_11", 
    "eng_s_11", 
    "aca_s_11", 
    "saf_tot_11", 
    "com_tot_11", 
    "eng_tot_11", 
    "aca_tot_11",
]
survey = survey.reindex(survey_fields, axis=1)
data["survey"] = survey

# Print results for verification
print(data['survey'].head(5))
data['survey'].shape
```

          DBN  rr_s  rr_t  rr_p    N_s   N_t    N_p  saf_p_11  com_p_11  eng_p_11  \
    0  01M015   NaN    88    60    NaN  22.0   90.0       8.5       7.6       7.5   
    1  01M019   NaN   100    60    NaN  34.0  161.0       8.4       7.6       7.6   
    2  01M020   NaN    88    73    NaN  42.0  367.0       8.9       8.3       8.3   
    3  01M034  89.0    73    50  145.0  29.0  151.0       8.8       8.2       8.0   
    4  01M063   NaN   100    60    NaN  23.0   90.0       8.7       7.9       8.1   
    
          ...      eng_t_10  aca_t_11  saf_s_11  com_s_11  eng_s_11  aca_s_11  \
    0     ...           NaN       7.9       NaN       NaN       NaN       NaN   
    1     ...           NaN       9.1       NaN       NaN       NaN       NaN   
    2     ...           NaN       7.5       NaN       NaN       NaN       NaN   
    3     ...           NaN       7.8       6.2       5.9       6.5       7.4   
    4     ...           NaN       8.1       NaN       NaN       NaN       NaN   
    
       saf_tot_11  com_tot_11  eng_tot_11  aca_tot_11  
    0         8.0         7.7         7.5         7.9  
    1         8.5         8.1         8.2         8.4  
    2         8.2         7.3         7.5         8.0  
    3         7.3         6.7         7.1         7.9  
    4         8.5         7.6         7.9         8.0  
    
    [5 rows x 23 columns]
    




    (1702, 23)



### Add DBN columns


```python
# Change the column head to align with other data frame
data["hs_directory"]["DBN"] = data["hs_directory"]["dbn"]

# Set uniform field length to develop same size DBN value in the data frame
def pad_csd(num):
    string_representation = str(num)
    if len(string_representation) > 1:
        return string_representation
    else:
        return "0" + string_representation

# Call function to set same size of  DBN prefix
data["class_size"]["padded_csd"] = data["class_size"]["CSD"].apply(pad_csd)

# Generate DBN field by combining two columns 
data["class_size"]["DBN"] = data["class_size"]["padded_csd"] + data["class_size"]["SCHOOL CODE"]

# Print results for verification
data["class_size"]["DBN"].iloc[0:5]
```




    0    01M015
    1    01M015
    2    01M015
    3    01M015
    4    01M015
    Name: DBN, dtype: object



### Convert columns to numeric


```python
# List of useful columns from the sat_result data frame 
cols = ['SAT Math Avg. Score', 'SAT Critical Reading Avg. Score', 'SAT Writing Avg. Score']

# Convert the string data into numeric form, transfor errors into null
for c in cols:
    data["sat_results"][c] = pandas.to_numeric(data["sat_results"][c], errors="coerce")

# Combining three column valus into one and store it into a new column
data['sat_results']['sat_score'] = data['sat_results'][cols[0]] + data['sat_results'][cols[1]] + data['sat_results'][cols[2]]

# Display results for verification
data['sat_results']['sat_score'].iloc[0:5]
```




    0    1122.0
    1    1172.0
    2    1149.0
    3    1174.0
    4    1207.0
    Name: sat_score, dtype: float64



### Extract Latitude and Longiude from the Data


```python
# Function to extract latitude from the given string
def find_lat(loc):
    coords = re.findall("\(.+, .+\)", loc)
    lat = coords[0].split(",")[0].replace("(", "")
    return lat

# Function to extract longitude from the given string
def find_lon(loc):
    coords = re.findall("\(.+, .+\)", loc)
    lon = coords[0].split(",")[1].replace(")", "").strip()
    return lon

# Extract latitude and longitude from the column at store them in new columns
data["hs_directory"]["lat"] = data["hs_directory"]["Location 1"].apply(find_lat)
data["hs_directory"]["lon"] = data["hs_directory"]["Location 1"].apply(find_lon)

# Convert the extrated latitude and longitude into numeric form, transform errors into null
data["hs_directory"]["lat"] = pandas.to_numeric(data["hs_directory"]["lat"], errors="coerce")
data["hs_directory"]["lon"] = pandas.to_numeric(data["hs_directory"]["lon"], errors="coerce")

# Print results for verification
data['hs_directory'].head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>dbn</th>
      <th>school_name</th>
      <th>boro</th>
      <th>building_code</th>
      <th>phone_number</th>
      <th>fax_number</th>
      <th>grade_span_min</th>
      <th>grade_span_max</th>
      <th>expgrade_span_min</th>
      <th>expgrade_span_max</th>
      <th>...</th>
      <th>priority05</th>
      <th>priority06</th>
      <th>priority07</th>
      <th>priority08</th>
      <th>priority09</th>
      <th>priority10</th>
      <th>Location 1</th>
      <th>DBN</th>
      <th>lat</th>
      <th>lon</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>17K548</td>
      <td>Brooklyn School for Music &amp; Theatre</td>
      <td>Brooklyn</td>
      <td>K440</td>
      <td>718-230-6250</td>
      <td>718-230-6262</td>
      <td>9</td>
      <td>12</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>883 Classon Avenue\nBrooklyn, NY 11225\n(40.67...</td>
      <td>17K548</td>
      <td>40.670299</td>
      <td>-73.961648</td>
    </tr>
    <tr>
      <th>1</th>
      <td>09X543</td>
      <td>High School for Violin and Dance</td>
      <td>Bronx</td>
      <td>X400</td>
      <td>718-842-0687</td>
      <td>718-589-9849</td>
      <td>9</td>
      <td>12</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1110 Boston Road\nBronx, NY 10456\n(40.8276026...</td>
      <td>09X543</td>
      <td>40.827603</td>
      <td>-73.904475</td>
    </tr>
    <tr>
      <th>2</th>
      <td>09X327</td>
      <td>Comprehensive Model School Project M.S. 327</td>
      <td>Bronx</td>
      <td>X240</td>
      <td>718-294-8111</td>
      <td>718-294-8109</td>
      <td>6</td>
      <td>12</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>Then to New York City residents</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1501 Jerome Avenue\nBronx, NY 10452\n(40.84241...</td>
      <td>09X327</td>
      <td>40.842414</td>
      <td>-73.916162</td>
    </tr>
    <tr>
      <th>3</th>
      <td>02M280</td>
      <td>Manhattan Early College School for Advertising</td>
      <td>Manhattan</td>
      <td>M520</td>
      <td>718-935-3477</td>
      <td>NaN</td>
      <td>9</td>
      <td>10</td>
      <td>9</td>
      <td>14.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>411 Pearl Street\nNew York, NY 10038\n(40.7106...</td>
      <td>02M280</td>
      <td>40.710679</td>
      <td>-74.000807</td>
    </tr>
    <tr>
      <th>4</th>
      <td>28Q680</td>
      <td>Queens Gateway to Health Sciences Secondary Sc...</td>
      <td>Queens</td>
      <td>Q695</td>
      <td>718-969-3155</td>
      <td>718-969-3552</td>
      <td>6</td>
      <td>12</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>160-20 Goethals Avenue\nJamaica, NY 11432\n(40...</td>
      <td>28Q680</td>
      <td>40.718810</td>
      <td>-73.806500</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 61 columns</p>
</div>



### Condense Datasets

#### Data frame 'class_size'


```python
class_size = data["class_size"]

# Segregate the data frame from high school students under general education category
class_size = class_size[class_size["GRADE "] == "09-12"]
class_size = class_size[class_size["PROGRAM TYPE"] == "GEN ED"]
print(class_size[["GRADE ", "PROGRAM TYPE"]].head(5))

# Consolidate the data frame for unique DBN field
class_size = class_size.groupby("DBN").agg('mean')

# Converting back DBN as index to column 
class_size.reset_index(inplace=True)
data["class_size"] = class_size

# Print data frame for verification
data['class_size'].head(5)
```

        GRADE  PROGRAM TYPE
    225  09-12       GEN ED
    226  09-12       GEN ED
    227  09-12       GEN ED
    228  09-12       GEN ED
    229  09-12       GEN ED
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DBN</th>
      <th>CSD</th>
      <th>NUMBER OF STUDENTS / SEATS FILLED</th>
      <th>NUMBER OF SECTIONS</th>
      <th>AVERAGE CLASS SIZE</th>
      <th>SIZE OF SMALLEST CLASS</th>
      <th>SIZE OF LARGEST CLASS</th>
      <th>SCHOOLWIDE PUPIL-TEACHER RATIO</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01M292</td>
      <td>1</td>
      <td>88.0000</td>
      <td>4.000000</td>
      <td>22.564286</td>
      <td>18.50</td>
      <td>26.571429</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>01M332</td>
      <td>1</td>
      <td>46.0000</td>
      <td>2.000000</td>
      <td>22.000000</td>
      <td>21.00</td>
      <td>23.500000</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>01M378</td>
      <td>1</td>
      <td>33.0000</td>
      <td>1.000000</td>
      <td>33.000000</td>
      <td>33.00</td>
      <td>33.000000</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>01M448</td>
      <td>1</td>
      <td>105.6875</td>
      <td>4.750000</td>
      <td>22.231250</td>
      <td>18.25</td>
      <td>27.062500</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>01M450</td>
      <td>1</td>
      <td>57.6000</td>
      <td>2.733333</td>
      <td>21.200000</td>
      <td>19.40</td>
      <td>22.866667</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



#### Data frame 'demographics'


```python
# Seggregating the dataframe 'demographics' based on the 'schoolyear' to extract unique DBN
data["demographics"] = data["demographics"][data["demographics"]["schoolyear"] == 20112012]

# Print for verification
data['demographics'].head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DBN</th>
      <th>Name</th>
      <th>schoolyear</th>
      <th>fl_percent</th>
      <th>frl_percent</th>
      <th>total_enrollment</th>
      <th>prek</th>
      <th>k</th>
      <th>grade1</th>
      <th>grade2</th>
      <th>...</th>
      <th>black_num</th>
      <th>black_per</th>
      <th>hispanic_num</th>
      <th>hispanic_per</th>
      <th>white_num</th>
      <th>white_per</th>
      <th>male_num</th>
      <th>male_per</th>
      <th>female_num</th>
      <th>female_per</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>6</th>
      <td>01M015</td>
      <td>P.S. 015 ROBERTO CLEMENTE</td>
      <td>20112012</td>
      <td>NaN</td>
      <td>89.4</td>
      <td>189</td>
      <td>13</td>
      <td>31</td>
      <td>35</td>
      <td>28</td>
      <td>...</td>
      <td>63</td>
      <td>33.3</td>
      <td>109</td>
      <td>57.7</td>
      <td>4</td>
      <td>2.1</td>
      <td>97.0</td>
      <td>51.3</td>
      <td>92.0</td>
      <td>48.7</td>
    </tr>
    <tr>
      <th>13</th>
      <td>01M019</td>
      <td>P.S. 019 ASHER LEVY</td>
      <td>20112012</td>
      <td>NaN</td>
      <td>61.5</td>
      <td>328</td>
      <td>32</td>
      <td>46</td>
      <td>52</td>
      <td>54</td>
      <td>...</td>
      <td>81</td>
      <td>24.7</td>
      <td>158</td>
      <td>48.2</td>
      <td>28</td>
      <td>8.5</td>
      <td>147.0</td>
      <td>44.8</td>
      <td>181.0</td>
      <td>55.2</td>
    </tr>
    <tr>
      <th>20</th>
      <td>01M020</td>
      <td>PS 020 ANNA SILVER</td>
      <td>20112012</td>
      <td>NaN</td>
      <td>92.5</td>
      <td>626</td>
      <td>52</td>
      <td>102</td>
      <td>121</td>
      <td>87</td>
      <td>...</td>
      <td>55</td>
      <td>8.8</td>
      <td>357</td>
      <td>57.0</td>
      <td>16</td>
      <td>2.6</td>
      <td>330.0</td>
      <td>52.7</td>
      <td>296.0</td>
      <td>47.3</td>
    </tr>
    <tr>
      <th>27</th>
      <td>01M034</td>
      <td>PS 034 FRANKLIN D ROOSEVELT</td>
      <td>20112012</td>
      <td>NaN</td>
      <td>99.7</td>
      <td>401</td>
      <td>14</td>
      <td>34</td>
      <td>38</td>
      <td>36</td>
      <td>...</td>
      <td>90</td>
      <td>22.4</td>
      <td>275</td>
      <td>68.6</td>
      <td>8</td>
      <td>2.0</td>
      <td>204.0</td>
      <td>50.9</td>
      <td>197.0</td>
      <td>49.1</td>
    </tr>
    <tr>
      <th>35</th>
      <td>01M063</td>
      <td>PS 063 WILLIAM MCKINLEY</td>
      <td>20112012</td>
      <td>NaN</td>
      <td>78.9</td>
      <td>176</td>
      <td>18</td>
      <td>20</td>
      <td>30</td>
      <td>21</td>
      <td>...</td>
      <td>41</td>
      <td>23.3</td>
      <td>110</td>
      <td>62.5</td>
      <td>15</td>
      <td>8.5</td>
      <td>97.0</td>
      <td>55.1</td>
      <td>79.0</td>
      <td>44.9</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 38 columns</p>
</div>



#### Data frame 'graduation'


```python
# Seggregating the dataframe 'graduation' for features useful to get unique DBN
data["graduation"] = data["graduation"][data["graduation"]["Cohort"] == "2006"]
data["graduation"] = data["graduation"][data["graduation"]["Demographic"] == "Total Cohort"]

# Print for verification
data["graduation"].head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Demographic</th>
      <th>DBN</th>
      <th>School Name</th>
      <th>Cohort</th>
      <th>Total Cohort</th>
      <th>Total Grads - n</th>
      <th>Total Grads - % of cohort</th>
      <th>Total Regents - n</th>
      <th>Total Regents - % of cohort</th>
      <th>Total Regents - % of grads</th>
      <th>...</th>
      <th>Regents w/o Advanced - n</th>
      <th>Regents w/o Advanced - % of cohort</th>
      <th>Regents w/o Advanced - % of grads</th>
      <th>Local - n</th>
      <th>Local - % of cohort</th>
      <th>Local - % of grads</th>
      <th>Still Enrolled - n</th>
      <th>Still Enrolled - % of cohort</th>
      <th>Dropped Out - n</th>
      <th>Dropped Out - % of cohort</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>Total Cohort</td>
      <td>01M292</td>
      <td>HENRY STREET SCHOOL FOR INTERNATIONAL</td>
      <td>2006</td>
      <td>78</td>
      <td>43</td>
      <td>55.1%</td>
      <td>36</td>
      <td>46.2%</td>
      <td>83.7%</td>
      <td>...</td>
      <td>36</td>
      <td>46.2%</td>
      <td>83.7%</td>
      <td>7</td>
      <td>9%</td>
      <td>16.3%</td>
      <td>16</td>
      <td>20.5%</td>
      <td>11</td>
      <td>14.1%</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Total Cohort</td>
      <td>01M448</td>
      <td>UNIVERSITY NEIGHBORHOOD HIGH SCHOOL</td>
      <td>2006</td>
      <td>124</td>
      <td>53</td>
      <td>42.7%</td>
      <td>42</td>
      <td>33.9%</td>
      <td>79.2%</td>
      <td>...</td>
      <td>34</td>
      <td>27.4%</td>
      <td>64.2%</td>
      <td>11</td>
      <td>8.9%</td>
      <td>20.8%</td>
      <td>46</td>
      <td>37.1%</td>
      <td>20</td>
      <td>16.100000000000001%</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Total Cohort</td>
      <td>01M450</td>
      <td>EAST SIDE COMMUNITY SCHOOL</td>
      <td>2006</td>
      <td>90</td>
      <td>70</td>
      <td>77.8%</td>
      <td>67</td>
      <td>74.400000000000006%</td>
      <td>95.7%</td>
      <td>...</td>
      <td>67</td>
      <td>74.400000000000006%</td>
      <td>95.7%</td>
      <td>3</td>
      <td>3.3%</td>
      <td>4.3%</td>
      <td>15</td>
      <td>16.7%</td>
      <td>5</td>
      <td>5.6%</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Total Cohort</td>
      <td>01M509</td>
      <td>MARTA VALLE HIGH SCHOOL</td>
      <td>2006</td>
      <td>84</td>
      <td>47</td>
      <td>56%</td>
      <td>40</td>
      <td>47.6%</td>
      <td>85.1%</td>
      <td>...</td>
      <td>23</td>
      <td>27.4%</td>
      <td>48.9%</td>
      <td>7</td>
      <td>8.300000000000001%</td>
      <td>14.9%</td>
      <td>25</td>
      <td>29.8%</td>
      <td>5</td>
      <td>6%</td>
    </tr>
    <tr>
      <th>31</th>
      <td>Total Cohort</td>
      <td>01M515</td>
      <td>LOWER EAST SIDE PREPARATORY HIGH SCHO</td>
      <td>2006</td>
      <td>193</td>
      <td>105</td>
      <td>54.4%</td>
      <td>91</td>
      <td>47.2%</td>
      <td>86.7%</td>
      <td>...</td>
      <td>22</td>
      <td>11.4%</td>
      <td>21%</td>
      <td>14</td>
      <td>7.3%</td>
      <td>13.3%</td>
      <td>53</td>
      <td>27.5%</td>
      <td>35</td>
      <td>18.100000000000001%</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 23 columns</p>
</div>



### Convert AP scores to numeric


```python
# Convert 'ap_2010' data frame columns to numeric format, transform errors into null
cols = ['AP Test Takers ', 'Total Exams Taken', 'Number of Exams with scores 3 4 or 5']

for col in cols:
    data["ap_2010"][col] = pandas.to_numeric(data["ap_2010"][col], errors="coerce")
    
# Print for verification
print(data['ap_2010'].shape)
data["ap_2010"].head(5)
```

    (258, 5)
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DBN</th>
      <th>SchoolName</th>
      <th>AP Test Takers</th>
      <th>Total Exams Taken</th>
      <th>Number of Exams with scores 3 4 or 5</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01M448</td>
      <td>UNIVERSITY NEIGHBORHOOD H.S.</td>
      <td>39.0</td>
      <td>49.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>01M450</td>
      <td>EAST SIDE COMMUNITY HS</td>
      <td>19.0</td>
      <td>21.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>01M515</td>
      <td>LOWER EASTSIDE PREP</td>
      <td>24.0</td>
      <td>26.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>01M539</td>
      <td>NEW EXPLORATIONS SCI,TECH,MATH</td>
      <td>255.0</td>
      <td>377.0</td>
      <td>191.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>02M296</td>
      <td>High School of Hospitality Management</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



### Combine the Datasets


```python
combined = data["sat_results"]

combined = combined.merge(data["ap_2010"], on="DBN", how="left")
combined = combined.merge(data["graduation"], on="DBN", how="left")

# Print for verification
print(combined.shape)
combined.head(5)

```

    (479, 33)
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DBN</th>
      <th>SCHOOL NAME</th>
      <th>Num of SAT Test Takers</th>
      <th>SAT Critical Reading Avg. Score</th>
      <th>SAT Math Avg. Score</th>
      <th>SAT Writing Avg. Score</th>
      <th>sat_score</th>
      <th>SchoolName</th>
      <th>AP Test Takers</th>
      <th>Total Exams Taken</th>
      <th>...</th>
      <th>Regents w/o Advanced - n</th>
      <th>Regents w/o Advanced - % of cohort</th>
      <th>Regents w/o Advanced - % of grads</th>
      <th>Local - n</th>
      <th>Local - % of cohort</th>
      <th>Local - % of grads</th>
      <th>Still Enrolled - n</th>
      <th>Still Enrolled - % of cohort</th>
      <th>Dropped Out - n</th>
      <th>Dropped Out - % of cohort</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01M292</td>
      <td>HENRY STREET SCHOOL FOR INTERNATIONAL STUDIES</td>
      <td>29</td>
      <td>355.0</td>
      <td>404.0</td>
      <td>363.0</td>
      <td>1122.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>36</td>
      <td>46.2%</td>
      <td>83.7%</td>
      <td>7</td>
      <td>9%</td>
      <td>16.3%</td>
      <td>16</td>
      <td>20.5%</td>
      <td>11</td>
      <td>14.1%</td>
    </tr>
    <tr>
      <th>1</th>
      <td>01M448</td>
      <td>UNIVERSITY NEIGHBORHOOD HIGH SCHOOL</td>
      <td>91</td>
      <td>383.0</td>
      <td>423.0</td>
      <td>366.0</td>
      <td>1172.0</td>
      <td>UNIVERSITY NEIGHBORHOOD H.S.</td>
      <td>39.0</td>
      <td>49.0</td>
      <td>...</td>
      <td>34</td>
      <td>27.4%</td>
      <td>64.2%</td>
      <td>11</td>
      <td>8.9%</td>
      <td>20.8%</td>
      <td>46</td>
      <td>37.1%</td>
      <td>20</td>
      <td>16.100000000000001%</td>
    </tr>
    <tr>
      <th>2</th>
      <td>01M450</td>
      <td>EAST SIDE COMMUNITY SCHOOL</td>
      <td>70</td>
      <td>377.0</td>
      <td>402.0</td>
      <td>370.0</td>
      <td>1149.0</td>
      <td>EAST SIDE COMMUNITY HS</td>
      <td>19.0</td>
      <td>21.0</td>
      <td>...</td>
      <td>67</td>
      <td>74.400000000000006%</td>
      <td>95.7%</td>
      <td>3</td>
      <td>3.3%</td>
      <td>4.3%</td>
      <td>15</td>
      <td>16.7%</td>
      <td>5</td>
      <td>5.6%</td>
    </tr>
    <tr>
      <th>3</th>
      <td>01M458</td>
      <td>FORSYTH SATELLITE ACADEMY</td>
      <td>7</td>
      <td>414.0</td>
      <td>401.0</td>
      <td>359.0</td>
      <td>1174.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>01M509</td>
      <td>MARTA VALLE HIGH SCHOOL</td>
      <td>44</td>
      <td>390.0</td>
      <td>433.0</td>
      <td>384.0</td>
      <td>1207.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>23</td>
      <td>27.4%</td>
      <td>48.9%</td>
      <td>7</td>
      <td>8.300000000000001%</td>
      <td>14.9%</td>
      <td>25</td>
      <td>29.8%</td>
      <td>5</td>
      <td>6%</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 33 columns</p>
</div>




```python
to_merge = ["class_size", "demographics", "survey", "hs_directory"]

for m in to_merge:
    combined = combined.merge(data[m], on="DBN", how="inner")

# Print for verification
print(combined.shape)
combined.head(5)
```

    (363, 159)
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DBN</th>
      <th>SCHOOL NAME</th>
      <th>Num of SAT Test Takers</th>
      <th>SAT Critical Reading Avg. Score</th>
      <th>SAT Math Avg. Score</th>
      <th>SAT Writing Avg. Score</th>
      <th>sat_score</th>
      <th>SchoolName</th>
      <th>AP Test Takers</th>
      <th>Total Exams Taken</th>
      <th>...</th>
      <th>priority04</th>
      <th>priority05</th>
      <th>priority06</th>
      <th>priority07</th>
      <th>priority08</th>
      <th>priority09</th>
      <th>priority10</th>
      <th>Location 1</th>
      <th>lat</th>
      <th>lon</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01M292</td>
      <td>HENRY STREET SCHOOL FOR INTERNATIONAL STUDIES</td>
      <td>29</td>
      <td>355.0</td>
      <td>404.0</td>
      <td>363.0</td>
      <td>1122.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>Then to Manhattan students or residents</td>
      <td>Then to New York City residents</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>220 Henry Street\nNew York, NY 10002\n(40.7137...</td>
      <td>40.713764</td>
      <td>-73.985260</td>
    </tr>
    <tr>
      <th>1</th>
      <td>01M448</td>
      <td>UNIVERSITY NEIGHBORHOOD HIGH SCHOOL</td>
      <td>91</td>
      <td>383.0</td>
      <td>423.0</td>
      <td>366.0</td>
      <td>1172.0</td>
      <td>UNIVERSITY NEIGHBORHOOD H.S.</td>
      <td>39.0</td>
      <td>49.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>200 Monroe Street\nNew York, NY 10002\n(40.712...</td>
      <td>40.712332</td>
      <td>-73.984797</td>
    </tr>
    <tr>
      <th>2</th>
      <td>01M450</td>
      <td>EAST SIDE COMMUNITY SCHOOL</td>
      <td>70</td>
      <td>377.0</td>
      <td>402.0</td>
      <td>370.0</td>
      <td>1149.0</td>
      <td>EAST SIDE COMMUNITY HS</td>
      <td>19.0</td>
      <td>21.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>420 East 12 Street\nNew York, NY 10009\n(40.72...</td>
      <td>40.729783</td>
      <td>-73.983041</td>
    </tr>
    <tr>
      <th>3</th>
      <td>01M509</td>
      <td>MARTA VALLE HIGH SCHOOL</td>
      <td>44</td>
      <td>390.0</td>
      <td>433.0</td>
      <td>384.0</td>
      <td>1207.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>145 Stanton Street\nNew York, NY 10002\n(40.72...</td>
      <td>40.720569</td>
      <td>-73.985673</td>
    </tr>
    <tr>
      <th>4</th>
      <td>01M539</td>
      <td>NEW EXPLORATIONS INTO SCIENCE, TECHNOLOGY AND ...</td>
      <td>159</td>
      <td>522.0</td>
      <td>574.0</td>
      <td>525.0</td>
      <td>1621.0</td>
      <td>NEW EXPLORATIONS SCI,TECH,MATH</td>
      <td>255.0</td>
      <td>377.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>111 Columbia Street\nNew York, NY 10002\n(40.7...</td>
      <td>40.718725</td>
      <td>-73.979426</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 159 columns</p>
</div>



### Fill Up Null Values


```python
# Fill up the null values with the column average value
combined = combined.fillna(combined.mean())
combined = combined.fillna(0)

# Check for null values
print("Null Values in Combined Data Frame =", combined.isnull().sum().sum())
```

    Null Values in Combined Data Frame = 0
    

### Add a School District Column for Mapping


```python
def get_first_two_chars(dbn):
    return dbn[0:2]

combined["school_dist"] = combined["DBN"].apply(get_first_two_chars)

# Print for verification
combined["school_dist"].head(5)
```




    0    01
    1    01
    2    01
    3    01
    4    01
    Name: school_dist, dtype: object



### Find correlations


```python
correlations = combined.corr()
corr_satscore = correlations.corr()["sat_score"]
print(corr_satscore)
```

    SAT Critical Reading Avg. Score         0.997433
    SAT Math Avg. Score                     0.992862
    SAT Writing Avg. Score                  0.997205
    sat_score                               1.000000
    AP Test Takers                          0.742299
    Total Exams Taken                       0.747097
    Number of Exams with scores 3 4 or 5    0.751203
    Total Cohort                            0.469707
    CSD                                     0.209195
    NUMBER OF STUDENTS / SEATS FILLED       0.521990
    NUMBER OF SECTIONS                      0.497414
    AVERAGE CLASS SIZE                      0.580089
    SIZE OF SMALLEST CLASS                  0.547800
    SIZE OF LARGEST CLASS                   0.498482
    SCHOOLWIDE PUPIL-TEACHER RATIO               NaN
    schoolyear                                   NaN
    fl_percent                                   NaN
    frl_percent                            -0.926402
    total_enrollment                        0.493900
    ell_num                                -0.032734
    ell_percent                            -0.588053
    sped_num                                0.202543
    sped_percent                           -0.719101
    asian_num                               0.652992
    asian_per                               0.831369
    black_num                               0.178459
    black_per                              -0.401030
    hispanic_num                            0.143639
    hispanic_per                           -0.639662
    white_num                               0.706445
                                              ...   
    rr_p                                   -0.085942
    N_s                                     0.551170
    N_t                                     0.436806
    N_p                                     0.628105
    saf_p_11                               -0.078582
    com_p_11                               -0.308995
    eng_p_11                               -0.173111
    aca_p_11                               -0.171177
    saf_t_11                                0.275014
    com_t_11                                0.034989
    eng_t_10                                     NaN
    aca_t_11                                0.063366
    saf_s_11                                0.243283
    com_s_11                                0.083379
    eng_s_11                                0.134303
    aca_s_11                                0.216600
    saf_tot_11                              0.164197
    com_tot_11                             -0.068616
    eng_tot_11                             -0.026598
    aca_tot_11                              0.029286
    grade_span_max                               NaN
    expgrade_span_max                            NaN
    zip                                     0.002559
    total_students                          0.544247
    number_programs                         0.296832
    priority08                                   NaN
    priority09                                   NaN
    priority10                                   NaN
    lat                                    -0.416402
    lon                                    -0.424829
    Name: sat_score, Length: 67, dtype: float64
    

### Plot Correlations


```python
# Preparing a list of colors from matplotlib
colors_list = list(colors._colors_full_map.values())
random.shuffle(colors_list, random.random)

fig, ax = plt.subplots(figsize=(18, 12))
ax.bar(corr_satscore.index, corr_satscore, align='center', color=colors_list)
ax.set_xticklabels(corr_satscore.index, rotation=90)
ax.set_title("Correlation of Features with SAT Score")

plt.show()
```


![png](output_29_0.png)

We observe high correlations between SAT score and following factors:

o	Number of Students / Seats Filled
o	Average Class Size
o	The highest grade the school expects to serve eventually
o	Number of Teacher Respondents (-ve) 
o	SAT Critical Reading Average Score
o	Free Lunch Percent
o	Number of distinct programs available at the school (-ve)

It’s obvious to see how the ‘class-size’, ‘number of students’ and the ‘highest grade the school expects’ creates a competitive environment for the students to encourage them working hard to perform better in SAT.

The strong positive relationship of ‘SAT Critical Reading Average Score’ with the SAT score shows the impact of effective reading skills on the overall SAT performance. 

The positive correlation of ‘Free Lunch’ with SAT score tells the success story of government’s welfare program in the area of economically developing neighborhood and low-income immigrant regions. 

It is interesting to note that higher the number of teachers’ participation in survey for expectation about student’s academia negatively influence the overall student performance in SAT. 

The negative correlation of ‘Number of distinct programs available at the school’ with SAT score goes in reverse parity with the positive correlation of ‘class-size’ and ‘number of students’ factors above as more program diversity tends to reduce the class-size an number of students per course. 
COMMENT ABOUT ABOVE SCATTER PLOT.

### Analyze Effect of Safety on SAT Score


```python
plt.scatter(combined['saf_s_11'], combined['sat_score'])
plt.title("Correlation Between Safety and SAT Score")
plt.show()
```


![png](output_33_0.png)


There appears to be a positive correlation between safety and SAT score though not so strong. There are some schools that have high safety standard and achieve high SAT score and some schools with low safety standard got low SAT score. Majority of the school from the sample falls between the safety score of 6.0 to 7.5 with an average SAT score below 1500. 

### Map Safety Score by Districts


```python
m = Basemap(
    projection='merc', 
    llcrnrlat=40.496044, 
    urcrnrlat=40.915256, 
    llcrnrlon=-74.255735, 
    urcrnrlon=-73.700272,
    resolution='i'
)

m.drawmapboundary(fill_color='#85A6D9')
m.drawcoastlines(color='#6D5F47', linewidth=.4)
m.drawrivers(color='#6D5F47', linewidth=.4)

distr = combined.groupby("school_dist").mean()
distr.reset_index(inplace=True)

longitudes = (distr["lon"]).tolist()
latitudes = (distr["lat"]).tolist()
m.scatter(longitudes, latitudes, s=20, zorder=2, latlon=True, c=distr["saf_s_11"])
plt.show()
```

    C:\Users\Yogi_Ashwast\Anaconda3\lib\site-packages\mpl_toolkits\basemap\__init__.py:1708: MatplotlibDeprecationWarning: The axesPatch function was deprecated in version 2.1. Use Axes.patch instead.
      limb = ax.axesPatch
    C:\Users\Yogi_Ashwast\Anaconda3\lib\site-packages\mpl_toolkits\basemap\__init__.py:1711: MatplotlibDeprecationWarning: The axesPatch function was deprecated in version 2.1. Use Axes.patch instead.
      if limb is not ax.axesPatch:
    


![png](output_36_1.png)


Brooklyn seems to have better safety score compared to the same for the parts of Manhattan, Queens and Bronx region.  

### Evaluate Racial Performance in SAT


```python
# Listing the races of interest
races = ["white_per", "asian_per", "black_per", "hispanic_per"]
racial_per = combined[races]

# Extracting the coorelation value for the shortlisted races
value_ht = combined.corr()["sat_score"][races]

# Establish plot parameters
x_cor = [1,2,3,4]
random.shuffle(colors_list, random.random)
plt.bar(x_cor, value_ht, width=0.5, align="center", tick_label=races, color=colors_list)
plt.xlim(0,5)
plt.xticks(rotation=90)
plt.title("Correlation of Whites, Asians, Blacks and Hispanics with SAT Score")

plt.show()
```


![png](output_39_0.png)


The whites and the Asians are found having strong positive correlation while the Blacks and the Hispanic are found having moderate negative correlation with the SAT score. 

This is due to the fact that the Hispanic and the Blacks might be coming from the immigrant families. The socio-economic factors, family support and surrounding environment play significant role in overall performance of the students. 

### Plot Correlation Between Hispanic Proportion & SAT Score


```python
plt.scatter(combined['hispanic_per'], combined['sat_score'])
plt.title("Correlation Between Hispanic Percent and SAT Score")

plt.show()
```


![png](output_42_0.png)


There seems to be a moderately strong downward trend with the increase of Hispanic Population. Very small portion of population attains a SAT score of 1800 or more while majority falls under the score of 1500. 

### Dependency: Low Sat Score & Hispanic Percent


```python
low_sat_high_hisp = combined[combined["sat_score"] < 1400]
low_sat_high_hisp = low_sat_high_hisp[low_sat_high_hisp["hispanic_per"] > 40]
sat_sc = low_sat_high_hisp["sat_score"].values
hisp_per = low_sat_high_hisp["hispanic_per"].values

plt.scatter(sat_sc, hisp_per)
plt.xlabel("Sat Score")
plt.ylabel("Hispanic Percentage")
plt.title("Correlation Between Hispanic Percent (> 40%) and SAT Score (< 1400)")
print("Correlation Value =", low_sat_high_hisp.corr()["sat_score"]["hispanic_per"])
```

    Correlation Value = -0.41737620009586124
    


![png](output_45_1.png)


Majority of the schools with Hispanic population in the range of 40% - 80% get average SAT score of around 1150. The results become clearly evident when plotted with 40% or more Hispanic Proportion for SAT score of 1400 or less. 

This is mainly due to the immigrant population along with the socio-economic and demographic factors.

### List Schools with Hispanic More Than 95%


```python
hisp_per_95 = combined[combined["hispanic_per"] > 95]
print(hisp_per_95["SCHOOL NAME"].unique())
```

    ['MANHATTAN BRIDGES HIGH SCHOOL'
     'WASHINGTON HEIGHTS EXPEDITIONARY LEARNING SCHOOL'
     'GREGORIO LUPERON HIGH SCHOOL FOR SCIENCE AND MATHEMATICS'
     'ACADEMY FOR LANGUAGE AND TECHNOLOGY'
     'INTERNATIONAL SCHOOL FOR LIBERAL ARTS'
     'PAN AMERICAN INTERNATIONAL HIGH SCHOOL AT MONROE'
     'MULTICULTURAL HIGH SCHOOL' 'PAN AMERICAN INTERNATIONAL HIGH SCHOOL']
    

### List  Schools with Hispanic Less Than 10%


```python
hisp_10_sat_1800 = combined[combined["hispanic_per"] < 10]
hisp_10_sat_1800 = hisp_10_sat_1800[hisp_10_sat_1800["sat_score"] > 1800]
print(hisp_10_sat_1800["SCHOOL NAME"].unique())
```

    ['STUYVESANT HIGH SCHOOL' 'BRONX HIGH SCHOOL OF SCIENCE'
     'BROOKLYN TECHNICAL HIGH SCHOOL'
     'QUEENS HIGH SCHOOL FOR THE SCIENCES AT YORK COLLEGE'
     'STATEN ISLAND TECHNICAL HIGH SCHOOL']
    

### Enlist Schools in NYC with Low Total Enrollment and Low SAT Score


```python
# Find the school with low enrolllment that get low SAT score
low_enrollment = combined[(combined['total_enrollment'] < 1000) & (combined['sat_score'] < 1000) ]

# Remove rows with invalid school name
low_enrollment = low_enrollment[low_enrollment['School Name'] != 0]

# Print for verification
low_enrollment['School Name']
```




    91       INTERNATIONAL COMMUNITY HIGH SCHOOL
    126          BRONX INTERNATIONAL HIGH SCHOOL
    139    KINGSBRIDGE INTERNATIONAL HIGH SCHOOL
    141    INTERNATIONAL SCHOOL FOR LIBERAL ARTS
    179            HIGH SCHOOL OF WORLD CULTURES
    188       BROOKLYN INTERNATIONAL HIGH SCHOOL
    225    INTERNATIONAL HIGH SCHOOL AT PROSPECT
    237               IT TAKES A VILLAGE ACADEMY
    253                MULTICULTURAL HIGH SCHOOL
    286    PAN AMERICAN INTERNATIONAL HIGH SCHOO
    Name: School Name, dtype: object



### Plot Correlation Between Sat Score & Gender


```python
gender = ["male_per", "female_per"]
cor_val = combined.corr()["sat_score"][gender]
x_val = [1, 1.0070]
random.shuffle(colors_list, random.random)

plt.bar(x_val, cor_val, 0.005, align='center', tick_label=gender, color=colors_list)
plt.xlim(0.995,1.011)
plt.ylabel("Correlation Value")
plt.xticks(rotation=90)
plt.title("Correlation Between Gender and SAT Score")
plt.show()
```


![png](output_54_0.png)


Female show very weak positive and male show very weak negative correlation for SAT score. This shows the relative performance of female and male students – which is more or less the same. 

### High SAT Score & High Female Percentage


```python
high_sat_n_fem = combined[combined["female_per"] > 50]
high_sat_n_fem = high_sat_n_fem[high_sat_n_fem["sat_score"] > 1500]
print("Schools with SAT > 1500 & Female > 50% =\n", high_sat_n_fem["SCHOOL NAME"].unique())
   
# Plot the scatter diagram 
plt.scatter(combined["sat_score"], combined["female_per"])
plt.xlabel("Sat Score")
plt.ylabel("female_per")
plt.title("Correlation Between Female Percent (> 50%) and SAT Score (> 1500)")

print("\nCorrelation Value between SAT Score and Female Percentage =", high_sat_n_fem.corr()["sat_score"]["female_per"])
```

    Schools with SAT > 1500 & Female > 50% =
     ['NEW EXPLORATIONS INTO SCIENCE, TECHNOLOGY AND MATH HIGH SCHOOL'
     'BARD HIGH SCHOOL EARLY COLLEGE'
     'PROFESSIONAL PERFORMING ARTS HIGH SCHOOL'
     'BARUCH COLLEGE CAMPUS HIGH SCHOOL'
     'N.Y.C. LAB SCHOOL FOR COLLABORATIVE STUDIES'
     'ELEANOR ROOSEVELT HIGH SCHOOL' 'MILLENNIUM HIGH SCHOOL'
     'BEACON HIGH SCHOOL'
     'FIORELLO H. LAGUARDIA HIGH SCHOOL OF MUSIC & ART AND PERFORMING ARTS'
     'LEON M. GOLDSTEIN HIGH SCHOOL FOR THE SCIENCES'
     'BARD HIGH SCHOOL EARLY COLLEGE II' 'TOWNSEND HARRIS HIGH SCHOOL'
     'BENJAMIN N. CARDOZO HIGH SCHOOL' "SCHOLARS' ACADEMY"
     'QUEENS GATEWAY TO HEALTH SCIENCES SECONDARY SCHOOL'
     'BACCALAUREATE SCHOOL FOR GLOBAL EDUCATION']
    
    Correlation Value between SAT Score and Female Percentage = 0.44951913501293517
    


![png](output_57_1.png)


There exists moderately positive correlation between the female proportion and SAT score. While tested for pool of students having more than 50% female proportion and SAT score of greater than 1500, it is observed that around 40% - 65% of the total students attain SAT score in the range of 1000 – 1350. 

### SAT Score > 1700 & Female Percentage > 60


```python
fem_60_sat_1700 = combined[(combined["sat_score"] > 1700) & (combined["female_per"] > 60)]
print("Schools with SAT > 1700 & Female > 60% =\n", fem_60_sat_1700["SCHOOL NAME"].unique())
```

    Schools with SAT > 1700 & Female > 60% =
     ['BARD HIGH SCHOOL EARLY COLLEGE' 'ELEANOR ROOSEVELT HIGH SCHOOL'
     'BEACON HIGH SCHOOL'
     'FIORELLO H. LAGUARDIA HIGH SCHOOL OF MUSIC & ART AND PERFORMING ARTS'
     'TOWNSEND HARRIS HIGH SCHOOL']
    

### Relationship Between AP Test Takers & SAT Score


```python
combined["ap_per"] = combined["AP Test Takers "] / combined["total_enrollment"]
plt.scatter(combined["sat_score"], combined["ap_per"], color='r')
plt.xlabel("Sat Score")
plt.ylabel("AP Test Taker (% of Total Enrolled)")
plt.title("Correlation Between  AP Test Takers and SAT Score")
plt.show()

print("Corrleation value between SAT Score & Percent of AP Test Takers =", combined.corr()["sat_score"]["ap_per"])
```


![png](output_62_0.png)


    Corrleation value between SAT Score & Percent of AP Test Takers = 0.05717081390766967
    

No correlation is found between the AP Test Takers and the SAT score. In fact, up to 40% of the total enrollment who took AP Test scored less than 1400 in SAT. There are few percent of students who took AP Test and secured SAT score of 1800 – 2000. 

The data about students’ performance in AP Test Vs. SAT could give us more insight to further comment about the AP Test results predictive relevance for SAT score.

### Relationship Between Class Size & SAT Score


```python
plt.scatter(combined["sat_score"], combined["AVERAGE CLASS SIZE"], color='b')
plt.xlabel("Sat Score")
plt.ylabel("Average Class Size")
plt.title("Correlation Between Class Size and SAT Score")
plt.show()

print("Corrleation value between SAT Score & Average Class Size =", combined.corr()["sat_score"]["AVERAGE CLASS SIZE"])
```


![png](output_65_0.png)


    Corrleation value between SAT Score & Average Class Size = 0.3810143308095523
    

Moderately strong positive correlation has been observed between the class size and SAT score. Students’ SAT score slowly improves as the class size increases from 20 to 30 students. Majority of the students score between 1000 – 1400 irrespective of class size. However, there are few exceptional cases where the students score beyond 1800.  

This clearly shows that performance of students in SAT is strongly impacted by his/her class size, higher student-teacher ratio and consequently the dense social environment -which collectively proves to be encouraging for the students.  

### Correlation Between Different in Parent, Teacher and Student Responses to Surveys with SAT Score

#### Listing and Cleaning Data


```python
# short listing the relevant columns 
surv_col = ['aca_p_11', 'aca_t_11', 'aca_s_11', 'sat_score']
response = combined[surv_col]

# Cleaning the data with null values
response = response.dropna(axis=0, how='any')

# Making sure no null is left
response.isnull().sum().sum()
```




    0



#### Develop Survey Response Differrence Data


```python
# Developing the survey difference response data
response['aca_p_s'] = (response['aca_p_11'] - response['aca_s_11']).abs()
response['aca_p_t'] = (response['aca_p_11'] - response['aca_t_11']).abs()
response['aca_t_s'] = (response['aca_t_11'] - response['aca_s_11']).abs()

# Plot survey response difference
resp_cols = ['aca_p_s', 'aca_p_t', 'aca_t_s']

# Print for verfication
print(response[resp_cols].head())
```

        aca_p_s  aca_p_t   aca_t_s
    0  0.900000      1.1  0.200000
    1  0.300000      0.0  0.300000
    2  1.018611      0.4  1.418611
    3  0.300000      0.5  0.200000
    4  0.700000      1.1  0.400000
    

#### Correlation Between Parent-Student Survey Difference Response & SAT Score


```python
pss_cor0 = response.corr()[resp_cols[0]]["sat_score"]
print("\nCorrelation between Parent-Student Survey Response & SAT Score =", 
      pss_cor0)
plt.scatter(response[resp_cols[0]], response["sat_score"])
plt.title("Correlation for Difference between Parent-Student Survey \
Response and SAT Score")
plt.show()
```

    
    Correlation between Parent-Student Survey Response & SAT Score = -0.2892526616448787
    


![png](output_73_1.png)


It appears that there is a moderately strong negative correlation between the difference in Parent-Student Survey Response and SAT Score. Hence, more similarity of parents and student’s opinion about the latter’s academic expectation, better would it be reflected in to the higher SAT score. In other words, more the disparity between parents and student’s responses for students’ academic expectation score, lower would be the SAT score.  

This clearly indicates that parental involvement in student’s education results into a better SAT performance and vice versa. 

#### Correlation Between Parent-Teacher Survey Difference Response & SAT Score


```python
pss_cor1 = response.corr()[resp_cols[1]]["sat_score"]
print("\nCorrelation between Parent-Teacher Survey Response & SAT Score =", 
      pss_cor1)
plt.scatter(response[resp_cols[1]], response["sat_score"])
plt.title("Correlation for Difference between Parent-Teacher Survey \
Response and SAT Score")
plt.show()
```

    
    Correlation between Parent-Teacher Survey Response & SAT Score = -0.11002982952218382
    


![png](output_76_1.png)


There exists weak negative relationship between the difference in parents and teachers’ survey response and SAT score. This indicates that difference of opinion between the parents and the teachers over the expectation of student’s academia has moderately reverse impact over student’s performance in SAT. In other words, less the differences between the parental and teacher’s opinion about student’s academic expectation, moderately better would be student’s performance in SAT. 

#### Correlation Between Teacher-Student Survey Difference Response & SAT Score


```python
pss_cor2 = response.corr()[resp_cols[2]]["sat_score"]
print("\nCorrelation between Teacher-Student Survey Response & SAT Score =", 
      pss_cor2)                  
plt.scatter(response[resp_cols[2]], response["sat_score"])
plt.title("Correlation for Difference between Teacher-Student Survey \
Response and SAT Score")
plt.show()
```

    
    Correlation between Teacher-Student Survey Response & SAT Score = -0.09657508196544748
    


![png](output_79_1.png)


No correlation is found between the difference in teachers’ and students’ survey response and SAT score. This indicates that difference of opinion between the teachers and students over the academic expectation for the students have no impact over student’s performance in SAT.

### Find out neighborhoods with Best Schools

#### Determine Top 10 Best School in NYC Based On SAT Score


```python
# Find the top 10 school based on the SAT score
good_schools = combined[combined['sat_score'] > 1750]
good_schools = good_schools.groupby('DBN').agg('max').sort_values(by='sat_score', ascending=False)
good_schools[['boro', 'sat_score', 'SCHOOL NAME', 'CSD', 'zip']].head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>boro</th>
      <th>sat_score</th>
      <th>SCHOOL NAME</th>
      <th>CSD</th>
      <th>zip</th>
    </tr>
    <tr>
      <th>DBN</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>02M475</th>
      <td>Manhattan</td>
      <td>2096.0</td>
      <td>STUYVESANT HIGH SCHOOL</td>
      <td>2</td>
      <td>10282</td>
    </tr>
    <tr>
      <th>10X445</th>
      <td>Bronx</td>
      <td>1969.0</td>
      <td>BRONX HIGH SCHOOL OF SCIENCE</td>
      <td>10</td>
      <td>10468</td>
    </tr>
    <tr>
      <th>31R605</th>
      <td>Staten Island</td>
      <td>1953.0</td>
      <td>STATEN ISLAND TECHNICAL HIGH SCHOOL</td>
      <td>31</td>
      <td>10306</td>
    </tr>
    <tr>
      <th>10X696</th>
      <td>Bronx</td>
      <td>1920.0</td>
      <td>HIGH SCHOOL OF AMERICAN STUDIES AT LEHMAN COLLEGE</td>
      <td>10</td>
      <td>10468</td>
    </tr>
    <tr>
      <th>25Q525</th>
      <td>Queens</td>
      <td>1910.0</td>
      <td>TOWNSEND HARRIS HIGH SCHOOL</td>
      <td>25</td>
      <td>11367</td>
    </tr>
    <tr>
      <th>28Q687</th>
      <td>Queens</td>
      <td>1868.0</td>
      <td>QUEENS HIGH SCHOOL FOR THE SCIENCES AT YORK CO...</td>
      <td>28</td>
      <td>11433</td>
    </tr>
    <tr>
      <th>01M696</th>
      <td>Manhattan</td>
      <td>1856.0</td>
      <td>BARD HIGH SCHOOL EARLY COLLEGE</td>
      <td>1</td>
      <td>10002</td>
    </tr>
    <tr>
      <th>05M692</th>
      <td>Manhattan</td>
      <td>1847.0</td>
      <td>HIGH SCHOOL FOR MATHEMATICS, SCIENCE AND ENGIN...</td>
      <td>5</td>
      <td>10031</td>
    </tr>
    <tr>
      <th>13K430</th>
      <td>Brooklyn</td>
      <td>1833.0</td>
      <td>BROOKLYN TECHNICAL HIGH SCHOOL</td>
      <td>13</td>
      <td>11217</td>
    </tr>
    <tr>
      <th>02M416</th>
      <td>Manhattan</td>
      <td>1758.0</td>
      <td>ELEANOR ROOSEVELT HIGH SCHOOL</td>
      <td>2</td>
      <td>10021</td>
    </tr>
  </tbody>
</table>
</div>



#### Gathering NYC Property Value Information


```python
cols = ['Borough', 'CD', 'SchoolDist', 'ZipCode', 'BldgClass', 'price_sf', 'Address', 'OwnerName']
brk_data = pandas.read_csv(r"databank/nyc_property/BK2017V11.csv", usecols = cols)
brx_data = pandas.read_csv(r"databank/nyc_property/BX2017V11.csv", usecols = cols)
mnh_data = pandas.read_csv(r"databank/nyc_property/MN2017V11.csv", usecols = cols)
qns_data = pandas.read_csv(r"databank/nyc_property/QN2017V11.csv", usecols = cols)
snr_data = pandas.read_csv(r"databank/nyc_property/SI2017V11.csv", usecols = cols)
prop_val = pandas.concat([brk_data, brx_data, mnh_data, qns_data, snr_data], axis=0)

# Print for verification
print(prop_val.shape)
prop_val.head(10)
```

    (53340, 8)
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Borough</th>
      <th>CD</th>
      <th>SchoolDist</th>
      <th>ZipCode</th>
      <th>Address</th>
      <th>BldgClass</th>
      <th>OwnerName</th>
      <th>price_sf</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BK</td>
      <td>309</td>
      <td>17.0</td>
      <td>11213.0</td>
      <td>400 UTICA AVENUE</td>
      <td>O2</td>
      <td>VIS BAN REALTY CORP</td>
      <td>50.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BK</td>
      <td>303</td>
      <td>13.0</td>
      <td>11205.0</td>
      <td>117 SANDFORD STREET</td>
      <td>G9</td>
      <td>117 SANFORD LLC</td>
      <td>50.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BK</td>
      <td>301</td>
      <td>14.0</td>
      <td>11222.0</td>
      <td>239 INDIA STREET</td>
      <td>O2</td>
      <td>INDIA STREET CORP.</td>
      <td>50.000000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BK</td>
      <td>315</td>
      <td>21.0</td>
      <td>11229.0</td>
      <td>1819 EAST 13 STREET</td>
      <td>D7</td>
      <td>AMK II REALTY LLC</td>
      <td>50.000000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BK</td>
      <td>313</td>
      <td>21.0</td>
      <td>11224.0</td>
      <td>3740 OCEANIC AVENUE</td>
      <td>M9</td>
      <td>KOZNITZ CONGREGATION</td>
      <td>50.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>BK</td>
      <td>318</td>
      <td>22.0</td>
      <td>11210.0</td>
      <td>1805 FLATBUSH AVENUE</td>
      <td>K4</td>
      <td>MERVEILLE, GLADYS</td>
      <td>50.000000</td>
    </tr>
    <tr>
      <th>6</th>
      <td>BK</td>
      <td>307</td>
      <td>15.0</td>
      <td>11215.0</td>
      <td>511 7 AVENUE</td>
      <td>W1</td>
      <td>DCAS/DEPARTMENT OF ED</td>
      <td>50.003959</td>
    </tr>
    <tr>
      <th>7</th>
      <td>BK</td>
      <td>301</td>
      <td>14.0</td>
      <td>11249.0</td>
      <td>58 NORTH 8 STREET</td>
      <td>O5</td>
      <td>101 KENT ASSOCIATES I</td>
      <td>50.008548</td>
    </tr>
    <tr>
      <th>8</th>
      <td>BK</td>
      <td>303</td>
      <td>14.0</td>
      <td>11205.0</td>
      <td>38 SKILLMAN STREET</td>
      <td>R4</td>
      <td>NaN</td>
      <td>50.015724</td>
    </tr>
    <tr>
      <th>9</th>
      <td>BK</td>
      <td>312</td>
      <td>21.0</td>
      <td>11230.0</td>
      <td>1613 MC DONALD AVENUE</td>
      <td>E1</td>
      <td>CB REALTY COMPANY LLC</td>
      <td>50.019231</td>
    </tr>
  </tbody>
</table>
</div>



### Finding Top 10 Cost Effective Properties for NYC School Neighborhood (2 Deals/School)

#### Define functions to seggregate residential class


```python
# Filter data frame for select residential building class 
def usage(char):
    usg = ['A', 'B', 'C', 'D', 'R']
    if char in usg:
        return 1
    else:
        return 0
```

#### Define Function to Extract Neighborhood  Details


```python
# Define function to extract the neighborhood details
def find_property(data, df):
    sch_dst = data[0]
    zip_code = data[1]
    df = df[(df['ZipCode'] == zip_code) & (df['SchoolDist'] == sch_dst)]
    
    count = 0
    j = 0
    k = 0
    m = df.shape[0]
    inp_vals = [([0] * 5) for i in range(2)]
    
    if (m == 0):
        inp_vals[j][k] = data[3]
        inp_vals[j][k+1] = "No Resi. Property Found"
        inp_vals[j][k+2] = "N/A"
        inp_vals[j][k+3] = "N/A"
        inp_vals[j][k+4] = data[2]
        j += 1
        k = 0
        
    elif (m == 1):
        i = 0
        inp_vals[j][k] = data[3]
        inp_vals[j][k+1] = df['Address'].iloc[i]
        inp_vals[j][k+2] = df['OwnerName'].iloc[i]
        inp_vals[j][k+3] = df['price_sf'].iloc[i]
        inp_vals[j][k+4] = data[2]
        j += 1
        k = 0

    else:
        for i in range(m):
            if (count < 2):
                inp_vals[j][k] = data[3]
                inp_vals[j][k+1] = df['Address'].iloc[i]
                inp_vals[j][k+2] = df['OwnerName'].iloc[i]
                inp_vals[j][k+3] = df['price_sf'].iloc[i]
                inp_vals[j][k+4] = data[2]
                j += 1
                k = 0
                count += 1
            elif (count >= 2):
                break
    return inp_vals
```

#### Top 10 Cost Effective Neighborhood Properties in NYC for Best Schools (2 choices / school)


```python
# Set up the data frame per ascending property prices, building class and location zip code
sorted_property = prop_val.sort_values(by=['price_sf', 'BldgClass', 'ZipCode'])
sorted_property['ZipCode'] = pandas.to_numeric(sorted_property['ZipCode'], errors = 'coerce')

# Seggregate data based on the building class for residential properties
sorted_property['Usage'] = sorted_property['BldgClass'].str[:1].apply(usage)
sorted_property = sorted_property[sorted_property['Usage'] == 1]

# Removing null values from the data frame
sorted_property = sorted_property.dropna()

# Extracting Top 10 Best Neighbordhood Data
neighbor = [([0]*5) for i in range(20)]
j = 0
for i in range(10):
    first_row, second_row = find_property(good_schools[['CSD', 'zip', 'SCHOOL NAME', 'boro']].iloc[i], sorted_property)
    for k in range(5):
        neighbor[j][k] = first_row[k]
        neighbor[j+1][k] = second_row[k]
    j += 2

# Set up neighbor data frame for output
cols = ['Borough', 'Property Address', 'Owner', 'Price/Sq Ft', 'Neighborhood School']
great_deal = pandas.DataFrame(columns=cols)

# Feed the final output in the data frame
for i in range(len(neighbor)):
        great_deal[cols[0]] = ([x[0] for x in neighbor])
        great_deal[cols[1]] = ([x[1] for x in neighbor])
        great_deal[cols[2]] = ([x[2] for x in neighbor])
        great_deal[cols[3]] = ([x[3] for x in neighbor])
        great_deal[cols[4]] = ([x[4] for x in neighbor])

# Removing data with missing values and resetting the index
great_deal = great_deal[great_deal['Borough'] != 0]
great_deal.reset_index(inplace=True, drop=True)

# Print the final results results
print("\nList of Least Expensive Neighborhood With Great Schools: \n")
great_deal
```

    
    List of Least Expensive Neighborhood With Great Schools: 
    
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Borough</th>
      <th>Property Address</th>
      <th>Owner</th>
      <th>Price/Sq Ft</th>
      <th>Neighborhood School</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Manhattan</td>
      <td>201 WARREN STREET</td>
      <td>TRIBECA NORTH END LLC</td>
      <td>112.479</td>
      <td>STUYVESANT HIGH SCHOOL</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Manhattan</td>
      <td>399 CHAMBERS STREET</td>
      <td>TRIBECA POINTE LLC</td>
      <td>114.277</td>
      <td>STUYVESANT HIGH SCHOOL</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Bronx</td>
      <td>2450 DAVIDSON AVENUE</td>
      <td>2460 DAVIDSON REALTY</td>
      <td>51.4895</td>
      <td>BRONX HIGH SCHOOL OF SCIENCE</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Bronx</td>
      <td>2776 SEDGWICK AVENUE</td>
      <td>TINEO, JOSE RAMON</td>
      <td>51.8865</td>
      <td>BRONX HIGH SCHOOL OF SCIENCE</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Staten Island</td>
      <td>10 PEEL PLACE</td>
      <td>ANN SOLAZZO</td>
      <td>24.215</td>
      <td>STATEN ISLAND TECHNICAL HIGH SCHOOL</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Staten Island</td>
      <td>41 PETER AVENUE</td>
      <td>SCAROLA, GREGG M</td>
      <td>24.2163</td>
      <td>STATEN ISLAND TECHNICAL HIGH SCHOOL</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Bronx</td>
      <td>2450 DAVIDSON AVENUE</td>
      <td>2460 DAVIDSON REALTY</td>
      <td>51.4895</td>
      <td>HIGH SCHOOL OF AMERICAN STUDIES AT LEHMAN COLLEGE</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Bronx</td>
      <td>2776 SEDGWICK AVENUE</td>
      <td>TINEO, JOSE RAMON</td>
      <td>51.8865</td>
      <td>HIGH SCHOOL OF AMERICAN STUDIES AT LEHMAN COLLEGE</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Queens</td>
      <td>152-11 UNION TURNPIKE</td>
      <td>ST. JOHN'S UNIVERSITY</td>
      <td>50.8769</td>
      <td>TOWNSEND HARRIS HIGH SCHOOL</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Queens</td>
      <td>154-27 64 AVENUE</td>
      <td>WISCHHUSEN RICHARD</td>
      <td>66.6693</td>
      <td>TOWNSEND HARRIS HIGH SCHOOL</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Queens</td>
      <td>162-25 112 ROAD</td>
      <td>CALVARY GRANDPARENT R</td>
      <td>59.1462</td>
      <td>QUEENS HIGH SCHOOL FOR THE SCIENCES AT YORK CO...</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Manhattan</td>
      <td>85 STANTON STREET</td>
      <td>85 OWNERS CORP</td>
      <td>97.2278</td>
      <td>BARD HIGH SCHOOL EARLY COLLEGE</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Manhattan</td>
      <td>138 LUDLOW STREET</td>
      <td>TRIPUKA REALTY CORP</td>
      <td>97.401</td>
      <td>BARD HIGH SCHOOL EARLY COLLEGE</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Manhattan</td>
      <td>No Resi. Property Found</td>
      <td>N/A</td>
      <td>N/A</td>
      <td>HIGH SCHOOL FOR MATHEMATICS, SCIENCE AND ENGIN...</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Brooklyn</td>
      <td>220 LINCOLN PLACE</td>
      <td>220 LINCOLN LLC</td>
      <td>50.0592</td>
      <td>BROOKLYN TECHNICAL HIGH SCHOOL</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Brooklyn</td>
      <td>233 BERKELEY PLACE</td>
      <td>233 BERKELEY PLACE LL</td>
      <td>50.2336</td>
      <td>BROOKLYN TECHNICAL HIGH SCHOOL</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Manhattan</td>
      <td>230 EAST 71 STREET</td>
      <td>230 OWNERS CORP</td>
      <td>97.0392</td>
      <td>ELEANOR ROOSEVELT HIGH SCHOOL</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Manhattan</td>
      <td>305 EAST 75 STREET</td>
      <td>GRUMA REALTY CORP</td>
      <td>97.0882</td>
      <td>ELEANOR ROOSEVELT HIGH SCHOOL</td>
    </tr>
  </tbody>
</table>
</div>



### Conclusion
•	We are able to know various critical factors that do/do not affect students’ performance in SAT examination. Based on this info, we can verify and validate how fare the current SAT system is for the diverse demographics like NYC. In case we found any flaws in the SAT system for unfair testing performances, we can get better idea about the causes to focus on and fix the system.

•	We understand the impact of various demographic, socio-economic, and current credit and grading system related factors over the performance of students in SAT examination. This helps us to determine and verify how this test maintains balance amongst these factors for overall fairness of test within the widely diverse community. 

•	We are able to determine top 10 best schools based on their average SAT score.

•	We shortlist the least expensive but situated with the top 10 best school neighborhood regions.

•	We could identify the regions of NYC neighborhood where schools do not perform well and understand whether or not there exists any ethnic diversity [to consider] for policy improvement. 

•	We learn the impact of similarity and disparity of students/teachers/parents’ opinion towards student’s academia over the SAT performance. This highlights the roles and responsibilities of various players of the game and its relative significance for the final outcome.

•	Based on the correlations and its severity on students’ SAT score, we can mention that SAT is reasonably fair for the diverse NYC demographics. 